export const instData = [
  {
    instImg: '/Images/Courses/instructor/Hemant_Pr.jpg',
    name: 'Hemant Kumar',
    profession: 'B.Tech, IIT Bombay',
    email: 'hitarthvyas02@gmail.com'
  },
  {
    instImg: '/Images/Courses/instructor/Vimal_Arjun_Pr.jpg',
    name: 'Vikas Tailor',
    profession: 'M.Tech, IIT Kharagpur',
    email: 'hitarthvyas02@gmail.com'
  },
  {
    instImg: '/Images/Courses/instructor/AnkitKumarSingh.jpg',
    name: 'Ankit Kumar Singh',
    profession: 'B.Tech, IIT Bhubaneswar',
    email: 'hitarthvyas02@gmail.com'
  },
  {
    instImg: '/Images/Courses/instructor/hvd.jpeg',
    name: 'Hitarth Vyas',
    profession: 'B.Tech, IIIT Dharwad',
    email: 'hitarthvyas02@gmail.com'
  },
]