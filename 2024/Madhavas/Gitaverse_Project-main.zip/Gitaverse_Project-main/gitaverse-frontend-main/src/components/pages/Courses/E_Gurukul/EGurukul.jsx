import React from 'react'

const EGurukul = () => {
  return (
    <div>
      <div className="h-garb">h</div>
      <h1>E-Gurukul(Coming Soon)</h1>
    </div>
  )
}

export default EGurukul