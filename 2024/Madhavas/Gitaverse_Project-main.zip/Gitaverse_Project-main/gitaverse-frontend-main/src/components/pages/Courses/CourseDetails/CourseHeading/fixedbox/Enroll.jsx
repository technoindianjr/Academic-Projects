import React, { useState, useEffect } from "react";
// import "./Enroll.css";

const Enroll = ({ isOpen, onClose, course }) => {
  return (
    <></>
  );
};

export default Enroll;
