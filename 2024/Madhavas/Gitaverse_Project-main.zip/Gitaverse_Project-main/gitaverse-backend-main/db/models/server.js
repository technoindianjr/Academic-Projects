const { Register } = require('./register.model');
const { Appointment } = require('./appointment.model')

module.exports = {
  Register,
  Appointment,
}