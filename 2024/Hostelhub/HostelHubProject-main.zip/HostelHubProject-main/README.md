# HostelHub-dashboard

## cd HostelHub-frontend

## npm install

## npm run dev

## Admin

### email - admin@hos.com

### password - 11111111

## Student

### email - surajmal@gmail.com

### password - 11111111

## Add .env file in root folder

```
VITE_BASE_URL=https://hostelhub-strapi.onrender.com
```
