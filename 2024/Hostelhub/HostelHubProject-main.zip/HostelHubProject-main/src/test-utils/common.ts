export const setTimeOutMock = (ms: number) =>
  new Promise((resolve) => setTimeout(resolve, ms));
