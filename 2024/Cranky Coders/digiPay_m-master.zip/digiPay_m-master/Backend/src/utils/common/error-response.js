const error ={
    success: false,
    message:'Something went wrong',
    data:{},
    error:{}
}

module.exports= error;