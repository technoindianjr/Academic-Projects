module.exports = {
    WalletService: require('./wallet-service'),
    UserService : require('./user-service'),
    TransactionService : require('./transaction-service'),
    IABankService: require('./iabank-service.js'),
    VoucherService: require('./voucher-service.js'),
    MerchantService: require('./merchant-service.js')
}