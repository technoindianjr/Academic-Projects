module.exports = {
    IABankMiddleware: require('./iaBank-middleware'),
    VoucherMiddleware: require('./voucher-middleware'),
    MerchantMiddleware: require('./merchant-middleware.js')
}
