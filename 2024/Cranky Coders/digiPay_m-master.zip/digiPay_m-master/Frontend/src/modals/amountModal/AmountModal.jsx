// import React from 'react';
// import "./amountModal.scss";
// import { CgClose } from "react-icons/cg";
// import { Link } from 'react-router-dom';

// const AmountModal = ({ isOpen, onClose }) => {
//     const amountWarpper = isOpen ? 'modal-container open' : 'modal-container';
//     return (
//         <>
//             <div className={amountWarpper}>
//                 <div className="amountContainer">
//                     <div className="start">
//                         <h2>Enter Amount</h2>
//                         <CgClose onClick={onClose} style={{ cursor: "pointer" }} />
//                     </div>
//                     <input type="number" name="amount" required />
//                     <Link to="/dashboard"><button>Add To Wallet</button></Link>
//                 </div>
//             </div>
//         </>
//     )
// }

// export default AmountModal;
