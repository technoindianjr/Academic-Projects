const AllRestaurants = () => {
  return <div>AllRestaurants</div>
}

export default AllRestaurants
