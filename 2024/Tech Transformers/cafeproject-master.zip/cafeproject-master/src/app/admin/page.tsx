"use client"
import Main from '@/components/adminComponents/Main'
import OrderBox from '@/components/adminComponents/OrderBox'
import { Image } from '@chakra-ui/next-js'
import React, { useEffect, useState } from 'react'

const page = () => {

  return (
    <Main/>
  )
}

export default page