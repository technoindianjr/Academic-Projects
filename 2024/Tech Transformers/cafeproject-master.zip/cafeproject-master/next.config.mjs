/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: [
      'images.unsplash.com',
      'bzktkujjnkxlljgpzaha.supabase.co',
      'images.pexels.com',
      "img.icons8.com",
      
    ]
  }
}

export default nextConfig
