# students.py

class OrganizationTests:
    @staticmethod
    def run_tests(driver):
        # Your test cases related to students
        driver.get("https://google.com")
        # Write your test logic here
