# Food-Ordering-System.
Case diagram and System Architecture of  Online Food  Ordering System

1.Use case diagram

![image](https://github.com/ManavTailor/Food-Ordering-System./assets/76099612/5a298524-576e-4193-a6f8-20c0cd2fd0c3)

2. System Architecture

![image](https://github.com/ManavTailor/Food-Ordering-System./assets/76099612/2d32da58-f27a-4b30-8469-6799f3ae99bc)

