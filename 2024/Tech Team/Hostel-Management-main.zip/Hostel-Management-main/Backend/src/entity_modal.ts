import { User, } from "./entities/User";
import { Person} from "./entities/Person";
import { Bed} from "./entities/Bed";
import { Room} from "./entities/Room";
import { Rent} from "./entities/Rent";

export const entities = [User,Bed,Room,Rent,Person];