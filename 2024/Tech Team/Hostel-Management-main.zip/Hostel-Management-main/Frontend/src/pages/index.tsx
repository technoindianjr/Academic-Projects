import LogIn from "@/components/LogIn";
import Rooms from "@/components/Rooms";
import Dashboard from "@/components/dashboard";

export default function Home() {
  return (
    <>
    <Rooms/>
      {/* <Dashboard /> */}
      {/* <LogIn /> */}
    </>
  );
}
