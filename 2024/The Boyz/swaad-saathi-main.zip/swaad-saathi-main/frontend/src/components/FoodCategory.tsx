import React from 'react'

const FoodCategory = () => {
  return (
    <div>FoodCategory</div>
  )
}

export default FoodCategory