import React from 'react'

const restaurant = () => {
  return (
    <div>restaurant</div>
  )
}

export default restaurant