import React from 'react'

const add = () => {
  return (
    <div>add</div>
  )
}

export default add