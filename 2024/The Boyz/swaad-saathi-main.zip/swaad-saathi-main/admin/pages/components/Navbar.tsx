import React from 'react'

const Navbar = () => {
  return (
    <div className='h-20 bg-slate-200 p-6'>
      <h5 className='font-semibold tracking-wider'>Admin Panel</h5>
    </div>
  )
}

export default Navbar