const orders = () => {
  return <div>orders</div>
}

export default orders
