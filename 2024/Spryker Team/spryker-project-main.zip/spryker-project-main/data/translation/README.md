Translations have been moved into `src/Pyz/Zed/Translator/data`.
