module.exports = require('@spryker/frontend-config.prettier/.prettierrc.json');
