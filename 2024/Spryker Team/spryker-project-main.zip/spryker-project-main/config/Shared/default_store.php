<?php

return getenv('SPRYKER_DEFAULT_STORE') ?: 'DE';
