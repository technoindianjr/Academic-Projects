# MajorProject
ABSTRACT
 
1. Purpose 

1.1. Introduction 

This Software Requirements Specification provides a complete description of all the functions and specifications of the Educational Android Application.
The main objective of this project is to raise awareness about menstruation and the menstrual cycle of young girls in rural areas and to educate them about the use of sanitary napkins instead of unhygienic products which affects their health a lot in different ways. It is a common problem faced by every girl and women and girls from rural areas do not want to talk and learn about it. This application provides a platform to learn and educate girls about this issue. 


1.2. Scope 

The scope of this android application is to spread awareness about menstruation hygiene among remote area adolescent girls. The users of this application are girls and women of villages who are not aware about the ways to stay healthy and hygienic during menstruation. This application will provide a means to interact with the girls and women facing the problem.


2. Document overview 

The remainder of this document is 8 chapters, the first providing an introduction to the project. It lists all the functions performed by the system. The second chapter consists of software requirements specification. The third chapter provides details about system analysis and design. The fourth chapter gives data dictionary information. The fifth chapter consists of snapshots of the complete project. The sixth chapter gives testing for the project. The seventh chapter tells about the conclusion and future enhancements of the project. The final chapter concerns the bibliography.

