<!DOCTYPE html>
<html>
<head>
<title>JobNet</title>
	 <link rel = "icon" href = "images/logo.png" 
        type = "image/logo.png">
</head>
<body>
<header>
<div style="background-color:#afabaa;width:100%;height:20%;">
<img src="images/logo1.png" width='300px' height='100px' style="float:center;margin-left:480px;margin-top:20px;"></img>
</div>
</header>
<div style="width:100%; height:2px;background-color:black">
</div>
<div style="width:100%; height:70%;">
<form action='forgotnext.php' method='post' >

<table border='0' style="width:40%; height:40%;margin-left:360px;box-shadow:5px 5px 5px 2px #afabaa;margin-top:70px;" rules='none' cellpadding=8 cellspacing=2>
<tr> <td colspan=2 align='center'><font size="5" color='#90c317'>FORGOT PASSWORD</td></tr> 


<td align='center' width=50%>COMPANY NAME</td>
	<td colspan='3' align='center' width=50%><input type='text'   required name='cnm' value=''></td>
  </tr>
  <tr><td></td></tr>
  <tr><td></td></tr>
  <tr><td></td></tr>
    <td align='center' width=50%>SECURITY PIN</td>
	<td colspan='3' align='center' width=50%><input type='password'   required name='cpin' value=''></td>
  </tr><tr> <td colspan=2 align='center' ><h6  style="margin-left:200px;font-size:14px; !important"class="h3 d-flex  align-items-center mb-10 text-primary">  Please enter the same details you used during registration.</h6></td></tr>

  <tr><td></td></tr>
  <tr><td></td></tr>
  <tr><td></td></tr>
  

   <td colspan='3' align='center'>
     <input style="background-color:#121212; border-color:#90c317; color:#fff;" type='submit'  value='SUBMIT'>
	</td>
</tr> </table>
</form>
</div>
</html>