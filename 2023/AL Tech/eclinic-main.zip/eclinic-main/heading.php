<style>
	td{
		text-align:center;
	}
</style>
<p align="right"><b>User Panel<b>
<br>
<a href='change_password.php'>Change Password</a>

<table width="100%">
	<tr>
		<td width="20%"><img src="logo.png"  width=270 height=150>
		<td align=center>
			<table width="100%" cellpadding=10 >
				<tr bgcolor=#008080>
					<td><a href='dr_regs.php'><font color='white' face='calibri'>Dr. Enroll
					<td><a href='all_drs.php'><font color='white' face='calibri'>All Drs.
					<td><a href='patient_regs.php'><font color='white' face='calibri'>New Patient
					<td><a href='patient_search.php'><font color='white' face='calibri'>Search Patient
					<td><a href='change_status.php'><font color='white' face='calibri'>Dr. Status
					<td><a href='today_detail.php'><font color='white' face='calibri'>Today's Status
					<td><a href='logout.php'><font color='white'face='calibri'>Logout
			</table>
</table>			
	<center>
	