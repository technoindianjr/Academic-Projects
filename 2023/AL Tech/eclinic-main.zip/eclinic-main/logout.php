<img src="logo.png"  width=170 height=100>
<center>

	<img src='logout.gif' width=550 height=400>
	<br>
	<a href='login.php'>Click Here to Login Again......!</a>
</center>