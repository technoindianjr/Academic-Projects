<img src="logo.png"  width=170 height=100>
<center>

	<img src='done.gif' width=350 height=200>
	<br>
	<h2>Password Hasa Been Changed Successfully......!</h2><br>
	<h3><a href='login.php'>Click Here to Login</a></h3>
</center>