<?php

$con = mysqli_connect("localhost","root","","eclinic");

if(!$con)
	die("Unable to Connect"); 
?>